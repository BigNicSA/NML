﻿namespace Nml.Improve.Me.Dependencies
{
	public class InReviewApplicationViewModel
		: ApplicationViewModel
	{
		public string InReviewMessage { get; set; }
		public Review InReviewInformation { get; set; }
	}
}