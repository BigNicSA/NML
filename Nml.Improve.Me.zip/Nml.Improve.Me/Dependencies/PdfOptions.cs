﻿namespace Nml.Improve.Me.Dependencies
{
	public class PdfOptions
	{
		public PageNumbers PageNumbers { get; set; }
		public HeaderOptions HeaderOptions { get; set; }
	}
}
