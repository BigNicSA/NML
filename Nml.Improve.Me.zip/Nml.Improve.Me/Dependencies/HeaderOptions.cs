﻿namespace Nml.Improve.Me.Dependencies
{
	public class HeaderOptions
	{
		public HeaderRepeat HeaderRepeat { get; set; }
		public PdfConstants HeaderHtml { get; set; }
	}
}