﻿namespace Nml.Improve.Me.Dependencies
{
	public enum PdfConstants
	{
		Header
	}
}