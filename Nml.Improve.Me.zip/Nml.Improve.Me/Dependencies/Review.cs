﻿namespace Nml.Improve.Me.Dependencies
{
	public class Review
	{
		public string Reason { get; set; }
	}
}