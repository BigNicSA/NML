﻿namespace Nml.Improve.Me.Dependencies
{
	public class Fund
	{
		public float Amount { get; set; }
		public double Fees { get; set; }
	}
}