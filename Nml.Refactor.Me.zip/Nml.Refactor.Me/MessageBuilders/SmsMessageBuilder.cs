﻿using Nml.Refactor.Me.MessageBuilders.Interfaces;
using Nml.Refactor.Me.Notifiers;
using Nml.Refactor.Me.Notifiers.Implementations;

namespace Nml.Refactor.Me.MessageBuilders
{
	public class SmsMessageBuilder : IMessageBuilder<NotificationMessage>
	{
		public NotificationMessage CreateMessage(NotificationMessage message)
		{
			return message;
		}
	}
}
