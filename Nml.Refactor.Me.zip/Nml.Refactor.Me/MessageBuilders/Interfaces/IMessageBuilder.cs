﻿using Nml.Refactor.Me.Notifiers;
using Nml.Refactor.Me.Notifiers.Implementations;

namespace Nml.Refactor.Me.MessageBuilders.Interfaces
{
	public interface IMessageBuilder<out TMessageType>
	{
		TMessageType CreateMessage(NotificationMessage message);
	}
}
