﻿namespace Nml.Refactor.Me.Dependencies
{
	public class LogManager
	{
		public static ILogger<object> For<T>()
		{
			throw new System.NotImplementedException();
		}
	}
}
